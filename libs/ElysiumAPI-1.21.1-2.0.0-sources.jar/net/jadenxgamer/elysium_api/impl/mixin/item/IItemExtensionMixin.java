package net.jadenxgamer.elysium_api.impl.mixin.item;

import net.jadenxgamer.elysium_api.api.util.RegistryAccessHelper;
import net.jadenxgamer.elysium_api.impl.core.datadriven.item.remainder_transformer.RemainderType;
import net.jadenxgamer.elysium_api.impl.registry.ElysiumRegistries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.common.extensions.IItemExtension;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(IItemExtension.class)
public interface IItemExtensionMixin {

    @Shadow Item self();

    @Inject(
            method = "getCraftingRemainingItem",
            at = @At(value = "HEAD"),
            cancellable = true
    )
    private void elysium_api$remainderTransformer(ItemStack stack, CallbackInfoReturnable<ItemStack> cir) {
        RegistryAccessHelper.getServer()
                .flatMap(access -> access.registryOrThrow(ElysiumRegistries.Keys.REMAINDER_TRANSFORMERS).stream()
                        .filter(s -> s.items().contains(self().builtInRegistryHolder()))
                        .findFirst())
                .ifPresent(transformer -> {
                    switch (transformer.remainderType()) {
                        case NONE -> cir.setReturnValue(null);
                        case NON_CONSUMABLE -> cir.setReturnValue(new ItemStack(self()));
                        case CHANGE_ITEM -> cir.setReturnValue(transformer.changeItem());
                    }
                });
    }

    @Inject(
            method = "hasCraftingRemainingItem",
            at = @At(value = "HEAD"),
            cancellable = true
    )
    private void elysium_api$hasRemainderTransformer(ItemStack stack, CallbackInfoReturnable<Boolean> cir) {
        RegistryAccessHelper.getServer()
                .flatMap(access -> access.registryOrThrow(ElysiumRegistries.Keys.REMAINDER_TRANSFORMERS).stream()
                        .filter(s -> s.items().contains(self().builtInRegistryHolder()))
                        .findFirst())
                .ifPresent(transformer -> cir.setReturnValue(transformer.remainderType() != RemainderType.NONE));
    }
}