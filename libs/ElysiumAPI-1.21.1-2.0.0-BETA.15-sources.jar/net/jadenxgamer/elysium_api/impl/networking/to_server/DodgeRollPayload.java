package net.jadenxgamer.elysium_api.impl.networking.to_server;

import net.jadenxgamer.elysium_api.ElysiumAPI;
import net.jadenxgamer.elysium_api.ElysiumFeatures;
import net.jadenxgamer.elysium_api.impl.networking.to_client.DodgeRollAnimationPayload;
import net.jadenxgamer.elysium_api.impl.registry.ElysiumAttachmentTypes;
import net.jadenxgamer.elysium_api.impl.registry.ElysiumAttributes;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import org.jetbrains.annotations.NotNull;

public final class DodgeRollPayload implements CustomPacketPayload {

    public static final Type<DodgeRollPayload> TYPE = new Type<>(ElysiumAPI.elysiumPath("dodge_roll_server"));

    public static final DodgeRollPayload INSTANCE = new DodgeRollPayload();

    public static final StreamCodec<FriendlyByteBuf, DodgeRollPayload> CODEC = StreamCodec.unit(INSTANCE);

    private DodgeRollPayload() {

    }

    @Override
    public @NotNull Type<DodgeRollPayload> type() {
        return TYPE;
    }

    public void handleDataOnServer(IPayloadContext context) {
        Player player = context.player();
        if (ElysiumFeatures.DODGE_ROLL.canDodge(player)) {

            player.getData(ElysiumAttachmentTypes.DODGE_COOLDOWN).set();
            player.invulnerableTime = 10;

            player.getFoodData().addExhaustion(4f);

            player.addDeltaMovement(Vec3.directionFromRotation(0, player.getYRot())
                    .scale(player.getAttributeValue(ElysiumAttributes.DODGE_POWER))
                    .scale(player.getSpeed() * 10));

            PacketDistributor.sendToPlayersTrackingEntity(context.player(), new DodgeRollAnimationPayload(context.player().getId()));
        }
    }
}
